package entities;
/**
 * Hostess life states
 * @author Mariana Pinto
 * @author André Alves
 */
public enum HostessStates {
    WAIT_FOR_FLIGHT,
    WAIT_FOR_PASSENGER,
    CHECK_PASSENGER,
    READY_TO_FLY
}
